package br.edu.ifrn.estudos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudosApplicationTests {

	@Test
	void contextLoads() {
	}

}
